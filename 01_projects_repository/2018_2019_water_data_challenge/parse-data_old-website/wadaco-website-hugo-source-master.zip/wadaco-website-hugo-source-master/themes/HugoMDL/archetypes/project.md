---
title: "My Project Title"
description: "Description of the sample project" #optional: curently displays as tooltip 
cardthumbimage: "/images/default-small.jpg" #optional: default solid color if unset
cardheaderimage: "/images/default.jpg" #optional: default solid color if unset
#cardbackground: "#263238" #optional: card background color; only shows when no image specified
#cardtitlecolor: "#fafafa" #optional: can be changed to make text visible over card image
repo: "http://github.com/" #optional: no icon appears if unset
web: "http://github.com/" #optional: no icon appears if unset
date: "2015-08-18"
categories:
    - "project"
tags:
    - "meta"
    - "project"
"author": # used to fill out the project page. Unset fields are removed from page
    name: "Firstname Lastname"
    description: "Writer of stuff"
    website: "http://example.com/"
    email: "firstname@example.com"
    twitter: "https://twitter.com/"
    github: "https://github.com/"
    image: "/images/avatar-64x64.png"

---

This is my project.


