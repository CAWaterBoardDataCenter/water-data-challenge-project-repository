---
title: WeedsViz
authors: 
- name: Junjun Dong
  url: ''
- name: Qingping Hou
  url: ''
team: 
  name: WeedsViz

repo: https://github.com/junjunjd/WeedsViz
topics:
- quality
initiatives:
- 2019-cawdc
awards:
- []
weight: -150
cardbackground: '#EC407A'
color_md: red-400

---

Delta Region Aquatic Invasive Plant Control Visualization

### [Project Website](https://junjunjd.github.io/WeedsViz/)

