---
title: Open Water Rate Specification (OWRS)
authors:
- name: Patrick Atwater
  url: ''
- name: Christopher Tull
  url: http://christophertull.org
- name: David Marulli
  url: ''
team:
  name: ARGO
  url: http://www.argolabs.org/
repo: https://github.com/waterdatacollaborative/Open-Water-Rate-Specification-2018
topics:
- tools
- affordability
initiatives:
- 2018-cawdc
awards:
- moonshot
weight: -353
cardbackground: '#78909C'
color_md: blue-gray-400

---



Additional resources:

- [Project webpage](https://github.com/California-Data-Collaborative)

