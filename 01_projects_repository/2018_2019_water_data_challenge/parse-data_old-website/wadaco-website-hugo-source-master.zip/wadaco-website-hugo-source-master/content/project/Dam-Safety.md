---
title: 'DAMMS: Dam Assessment Mapping and Safety System'
authors:
- name: Daniel Siegel
  url: ''
- name: Colin King-Bailey
  url: ''
- name: Jessica Rahman
  url: ''
- name: Dan Constable
  url: ''
team:
  name: Dammed if you do
  url: ''
repo: https://github.com/waterdatacollaborative/Dam-Safety-2018
topics:
- infrastructure
initiatives:
- 2018-cawdc
awards:
- teamspirit
weight: -352
cardbackground: '#00838F'
color_md: cyan-700

---

Communicating dam safety through visualizations, building support for change

Additional resources:

- [Project webpage](https://dam-safety.github.io/damss)

