---
title: Water Scarcity Clock
authors:
- name: Sara Biazar
  url: ''
- name: Iskra Ušćumlić
  url: ''
- name: Thomas Mitterling
  url: ''
- name: Peter Burek
  url: ''
- name: Peter Greve
  url: ''
- name: Robert Burtscher
  url: ''
- name: Jasmin Baier
  url: ''
team:
  name: World Data Lab & International Institute for Applied Systems Analysis
  url: ''
repo: ''
topics:
- availability
initiatives:
- 2019-cawdc
awards:
- []
weight: -354
cardbackground: '#00838F'
color_md: cyan-700

---

### [Project Website](https://www.worldwater.io/)

