---
title: Jata Water Solution
authors:
- name: Junlin Chen
  url: ''
- name: Jingjua Yao
  url: ''
- name: Zini Zhu
  url: ''
- name: Caidan Yang
  url: ''
- name: Jiajia Jing
  url: ''
team: 
  name: The Jata Solutions
repo: https://github.com/jyao8112/CA-Water-Contest.git
topics:
- tools
- quality
initiatives:
- 2019-cawdc
awards: risinginnovator
weight: -310
cardbackground: '#EC407A'
color_md: red-400

---

Empowering Community Residents with One Integrated Information Platform and Two-Way Data Communication



