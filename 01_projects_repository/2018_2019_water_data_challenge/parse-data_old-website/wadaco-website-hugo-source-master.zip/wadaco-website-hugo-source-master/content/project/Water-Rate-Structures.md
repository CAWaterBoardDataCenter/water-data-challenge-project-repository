---
title: Water Rate Structures– Do They Make Cents?
authors:
- name: Lauren Adams
  url: ''
- name: Benjamin Dawson
  url: ''
- name: Ian Morelan
  url: ''
- name: Kyle Onda
  url: ''
- name: Wai Yan Siu
  url: ''
- name: Joakim Weill
  url: ''
team:
  name: Econ on Tap
  url: ''
repo: ''
topics:
- affordability
initiatives:
- 2019-cawdc
awards:
- datalicious
weight: -354
cardbackground: '#00838F'
color_md: cyan-700

---

### [Project Website](https://ianartmor.github.io/ca_owrs/)

