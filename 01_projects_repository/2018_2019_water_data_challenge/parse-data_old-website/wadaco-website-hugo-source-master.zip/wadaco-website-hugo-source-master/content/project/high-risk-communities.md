---
title: Identifying high-risk communities
authors:
- name: Jacqueline Barkoski
  url: ''
- name: Chuan-Shin Chong
  url: ''
team:
  name: Code4Sac
  url: ''
repo: https://github.com/waterdatacollaborative/
topics:
- affordability
initiatives:
- 2018-cawdc
awards:
- risinginnovator
weight: -350
cardbackground: '#43A047'
color_md: green-500

---

Identifying communities with a high risk of shortage using a multifactor vulnerability score

Additional resources:

- [Project webpage](http://arcg.is/19OXPW)

