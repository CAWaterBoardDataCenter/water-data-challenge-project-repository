---
title: California Safe Drinking Water
authors:
- name: Aaron Hans
  url: ''
- name: Cori Gaul
  url: ''
- name: Michael Norelli
  url: ''
- name: Rucker Alex
  url: ''
- name: Alex Aruj
  url: ''
- name: Sean Pennino
  url: ''
team: 
  name: Code for America Open Oakland Water
repo: https://github.com/openoakland/clean-water
topics:
- quality
initiatives:
- 2019-cawdc
awards: enduringcivicengagement
weight: -310
cardbackground: '#EC407A'
color_md: red-400

---

### [Project website](http://water.openoakland.org/)




