---
title: Spotting the Drought
authors:
- name: Siu Lim Lee
  url: ''
- name: Lynn Gao
  url: ''

team: 
  name: Spotting the Drought
repo: ''
topics:
- availability
initiatives:
- 2019-cawdc
awards: []
weight: -310
cardbackground: '#EC407A'
color_md: red-400

---


### [Project Website](https://californiadrought.shinyapps.io/WaterWells/)


