---
title: How's My Water?
authors:
- name: Hadrien N Picq
  url: https://hp-nunes.github.io/
team: {}
repo: https://github.com/waterdatacollaborative/HowsMyWater-DataAnalysis
topics:
- quality
initiatives:
- 2018-cawdc
awards: []
weight: -310
cardbackground: '#EC407A'
color_md: red-400

---





