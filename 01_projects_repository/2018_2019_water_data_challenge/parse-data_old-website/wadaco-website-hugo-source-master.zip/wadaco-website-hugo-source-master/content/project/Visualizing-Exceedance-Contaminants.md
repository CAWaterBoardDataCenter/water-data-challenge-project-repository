---
title: Visualizing Exceedance of Contaminants
authors:
- name: Aaron Hans
  url: ''
- name: Robert Gibboni
  url: ''
- name: Rucker Alex
  url: ''
- name: Yotam Hacohen
  url: ''
team:
  name: OpenOakland
  url: ''
repo: https://github.com/waterdatacollaborative/OpenOakland_Exceedence-Levels-Vis
topics:
- quality
initiatives:
- 2018-cawdc
awards:
- design
weight: -351
cardbackground: '#EC407A'
color_md: red-400

---

Visualizing exceedance levels of water system contaminants.

Additional resources:

- [Project webpage](https://aaronhans.github.io/water-challenge/html/index.html)

