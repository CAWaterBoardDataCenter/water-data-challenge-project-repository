---
title: Water Quality Portal for California
authors:
- name: Rich Pauloo
  url: https://richpauloo.github.io
- name: Lindsay Poirier
  url: ''
- name: Andrew Essin
  url: ''
- name: Avery Kreuger
  url: ''
team:
  name: function(water, data) { science }
  url: ''
repo: https://github.com/caccr/cawdc_2019
topics:
- quality
initiatives:
- 2019-cawdc
awards:
- readytogo
weight: -354
cardbackground: '#00838F'
color_md: cyan-700

---

### [Project webpage](https://caccr.github.io/)

