---
title: Drinking Water Contaminant Classification
authors:
- name: Nicole Look
  url: https://github.com/nmlook
team: {}
repo: https://github.com/waterdatacollaborative/NicoleLook_Drinking-Water-Contaminant-Classification
topics:
- quality
- infrastructure
initiatives:
- 2018-cawdc
awards: []
weight: -311
cardbackground: '#EC407A'
color_md: red-400

---





