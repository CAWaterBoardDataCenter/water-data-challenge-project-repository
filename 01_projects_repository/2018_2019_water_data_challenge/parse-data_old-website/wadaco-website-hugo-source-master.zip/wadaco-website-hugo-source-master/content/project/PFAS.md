---
title: PFAS– We Eat It, We Drink It, We Breathe It
authors:
- name: Melissa Salazar
  url: ''

team:
  name: PFAS Away
  url: ''
repo: https://github.com/CAWaterBoardDataCenter/PFAS-Analysis-and-Intervention
topics:
- quality
initiatives:
- 2019-cawdc
awards:
- peopleschoice
weight: -355
cardbackground: '#78909C'
color_md: blue-gray-400

---


### [Project Webpage](https://meldataaa.shinyapps.io/PFAS_Analysis_and_Intervention/)
