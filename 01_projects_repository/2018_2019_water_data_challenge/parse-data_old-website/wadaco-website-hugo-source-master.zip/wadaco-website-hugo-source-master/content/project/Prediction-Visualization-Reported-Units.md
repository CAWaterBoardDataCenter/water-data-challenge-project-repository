---
title: Prediction and Visualization of Reported Units
authors:
- name: ' Anna Waldron'
  url: ''
- name: Elena Smith
  url: ''
team:
  name: Lovelace Ladies
  url: ''
repo: https://github.com/waterdatacollaborative/JPLCivicHackers_Prediction-Visualization-Reported-Units
topics:
- tools
initiatives:
- 2018-cawdc
awards:
- imagine-h2o
weight: -355
cardbackground: '#78909C'
color_md: blue-gray-400

---

Saving staff time by building a model that identifies Electronic Annual Reports (EARs) with errors. Can we learn more about contributing factors through geographic visualization?

Additional resources:

- [Project webpage](https://github.com/ozzysChiefDataScientist/water)

