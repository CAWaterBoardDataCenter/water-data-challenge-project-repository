---
title: The WeTap App
authors: 
- name: Evelyn Wendel
  url: ''
- name: Aaron Hans
  url: ''
- name: Susan Wrenn
  url: ''
- name: Jack Sahl
  url: ''
- name: Caleb Rabinowitz
  url: ''
- name: Charles Ellis
  url: ''
- name: Adam Western
  url: ''
team: 
  name: WeTap

repo: ''
topics:
- quality
- infrastructure
initiatives:
- 2019-cawdc
awards:
- moonshot
weight: -150
cardbackground: '#EC407A'
color_md: red-400

---

### [Project Webpage](http://wetap.org/)


