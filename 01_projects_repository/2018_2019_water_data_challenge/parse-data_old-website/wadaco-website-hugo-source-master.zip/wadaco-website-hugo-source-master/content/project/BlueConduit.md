---
title: Blue Conduit
authors:
- name: Dr. Eric Schwartz
  url: ''
- name: Dr. Jacob Abernethy
  url: ''
- name: Jared Webb
  url: ''
- name: Ian Robinson
  url: ''
- name: Brigadier General (ret.) Michael McDaniel
  url: ''

team: 
  name: BlueConduit
repo: ''
topics:
- infrastructure
- quality
initiatives:
- 2019-cawdc
awards: []
weight: -310
cardbackground: '#EC407A'
color_md: red-400

---

Using AI to reduce uncertainty of lead service line replacement




