---
name: 2018 CA Water Data Challenge
slug: 2018-cawdc
year: '2018'

---

<div style="display:flex;flex-direction:column;justify-content:center;align-items:center">
    <img style="display:block;max-width:100%;max-height:100%" src="https://pbs.twimg.com/media/DskS_s0U4AACL8C.jpg">
</div>


---
✔️4 months  
✔️25+ machine-readable datasets  
✔️15 events  
✔️$12,000 in "big checks"  
✔️20+ open data projects  

Additional resources:

- [#CAWaterDataChallenge](https://twitter.com/hashtag/cawaterdatachallenge?f=tweets&vertical=default) on Twitter



