---
name: Affordability
slug: affordability

---

Is water affordable? For many people, the answer is: unfortunately, not really.

These projects focus on using existing water data to quantify the economic impact of water on people and communities using it.

