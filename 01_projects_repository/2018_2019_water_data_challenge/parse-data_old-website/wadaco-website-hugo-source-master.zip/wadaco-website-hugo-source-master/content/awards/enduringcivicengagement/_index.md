---
name: Enduring Civic Engagement
slug: enduringcivicengagement
badge: "\U0001F3C6"

---

To honor the team that has had the most impact on communities and their interests, we are excited to announce the inaugural Enduring Civic Engagement Award. This award recognizes the importance of iteration, the value of gathering civic interests and honoring the community perspective on water data value.


