---
name: Team spirit and collaboration
slug: teamspirit
badge: "\U0001F3C6"

---


