---
name: Ready to go
slug: readytogo
badge: "\U0001F3C6"

---

This award looks at feasibility of implementation. It addresses real-world needs relevant to drinking water issues, demonstrating an understanding of constraints, including cost of implementation. It works “as is”, and has some level of interoperability with existing work or systems.

