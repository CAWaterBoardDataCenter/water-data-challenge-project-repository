---
name: Moonshot
slug: moonshot
badge: "\U0001F3C6"

---

This award looks at the most ambitious or highest potential for large impact as well as compelling concept and Creativity in approach.

