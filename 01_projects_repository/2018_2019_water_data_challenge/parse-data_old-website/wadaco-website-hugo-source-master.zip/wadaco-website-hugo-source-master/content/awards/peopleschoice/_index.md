---
name: People's choice
slug: peopleschoice
badge: "\U0001F3C6"

---

This award recognizes the project that has received the most votes from the summit's in-person participants.


