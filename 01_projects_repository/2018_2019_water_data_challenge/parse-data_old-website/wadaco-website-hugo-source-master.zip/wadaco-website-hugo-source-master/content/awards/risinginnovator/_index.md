---
name: Rising Innovator
slug: risinginnovator
badge: "\U0001F3C6"

---

This award is intended to recognize an emerging group of leaders in the water, technology, or innovation fields. The team demonstrated an innovative approach, has high leadership potential, and a diversity of organizations.

