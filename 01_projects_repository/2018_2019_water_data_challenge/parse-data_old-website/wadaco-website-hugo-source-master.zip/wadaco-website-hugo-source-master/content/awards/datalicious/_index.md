---
name: Most data-licious
slug: datalicious
badge: "\U0001F3C6"

---

This award is intended to recognize projects that effectively integrate data from different sources or organizations, including their own data.


