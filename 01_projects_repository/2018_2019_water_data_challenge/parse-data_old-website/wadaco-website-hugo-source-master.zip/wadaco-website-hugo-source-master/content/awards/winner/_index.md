---
name: Winner
slug: winner
badge: "\U0001F3C6"

---

Overall winner of the competition

