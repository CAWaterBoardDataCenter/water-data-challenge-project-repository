---
name: Change at Scale
slug: changeatscale
badge: "\U0001F3C6"

---

This award is new in 2019 and it aims to recognize the importance of scalability. The project that gets this award demonstrates impact at more than one scale and should have characteristics that reflect the success gained from iterating over multiple engagements with multiple parties at different scales.

