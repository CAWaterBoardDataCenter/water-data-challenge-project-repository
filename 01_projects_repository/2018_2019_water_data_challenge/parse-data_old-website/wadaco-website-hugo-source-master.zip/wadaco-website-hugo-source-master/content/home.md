---
title: "Home"
description: "About the Water Data Collaborative"
# date: "2015-08-18"
type: "static"
# layout: "single"

blurb: "Water data projects and resources"
# recentposts: 5
# recentprojects: 5
photo: "/img/wadaco-bear-logo.png"
# cardheaderimage: "/images/default.jpg" #optional: default solid color if unset
cardbackground: "#263238" #optional: card background color; only shows when no image specified
---

Pooling together water data resources, in California and beyond.
